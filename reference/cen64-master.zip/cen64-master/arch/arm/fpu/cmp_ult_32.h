//
// arch/arm/fpu/cmp_ult_32.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline uint8_t fpu_cmp_ult_32(
  const uint32_t *fs, const uint32_t *ft) {
  return 0;
}

