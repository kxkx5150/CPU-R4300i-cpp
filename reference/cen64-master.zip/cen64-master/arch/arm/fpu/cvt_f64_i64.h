//
// arch/arm/fpu/cvt_f64_i64.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline void fpu_cvt_f64_i64(const uint64_t *fs, uint64_t *fd) {
}

