//
// arch/arm/fpu/sqrt_32.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline void fpu_sqrt_32(const uint32_t *fs, uint32_t *fd) {
}

