//
// arch/arm/fpu/cvt_f64_f32.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline void fpu_cvt_f64_f32(const uint32_t *fs, uint64_t *fd) {
}

