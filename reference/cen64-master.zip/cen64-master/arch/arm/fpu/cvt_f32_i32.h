//
// arch/arm/fpu/cvt_f32_i32.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline void fpu_cvt_f32_i32(const uint32_t *fs, uint32_t *fd) {
}

