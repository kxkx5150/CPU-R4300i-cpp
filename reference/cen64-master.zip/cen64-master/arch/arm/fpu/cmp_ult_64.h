//
// arch/arm/fpu/cmp_ult_64.h
//
// This file is subject to the terms and conditions defined in
// 'LICENSE', which is part of this source code package.
//

static inline uint8_t fpu_cmp_ult_64(
  const uint64_t *fs, const uint64_t *ft) {
  return 0;
}

